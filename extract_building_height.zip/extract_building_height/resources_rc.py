# Stub de recursos (puedes compilar con: pyrcc5 resources.qrc -o resources_rc.py)
